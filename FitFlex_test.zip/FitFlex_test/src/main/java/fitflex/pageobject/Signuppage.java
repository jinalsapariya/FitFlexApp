package fitflex.pageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Signuppage {
    WebDriver driver;
    public Signuppage (WebDriver driver) {this.driver = driver; }

    public void authenticateuser (String email, String fullname, String password) throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            System.out.println(e.getMessage());
        }


        WebElement emailElement = driver.findElement(By.cssSelector("#u238_input"));
        if (emailElement.isDisplayed()){
            System.out.println("1. Validation Passed: ");
            System.out.println(" Email field is showing up on signup page");
        } else {
            System.out.println("1. validation Failed");
        }
        wait.until(ExpectedConditions.visibilityOf(emailElement));

        emailElement.sendKeys(email); // add emailId here

        Thread.sleep(1000);


        WebElement fnElement = driver.findElement(By.cssSelector("#u241_input"));
        wait.until(ExpectedConditions.visibilityOf(fnElement));
        fnElement.sendKeys(fullname); // add full name here
        Thread.sleep(1000);

        WebElement pswElement = driver.findElement(By.cssSelector("#u244_input"));
        wait.until(ExpectedConditions.visibilityOf(pswElement));
        pswElement.sendKeys(password); // add password here
        Thread.sleep(1000);

        WebElement confpswELement = driver.findElement(By.cssSelector("#u247_input"));
        wait.until(ExpectedConditions.visibilityOf(confpswELement));
        confpswELement.sendKeys(password); // add confirm password here
        Thread.sleep(1000);

        WebElement createacc = driver.findElement(By.xpath("//*[@id=\"u251_text\"]"));
        if (createacc.isDisplayed()){
            System.out.println(" create acc found ");
        } else {
            System.out.println(" Not found ");
        }
        wait.until(ExpectedConditions.visibilityOf(createacc));
        createacc.click();
        Thread.sleep(2000);
    }
}
