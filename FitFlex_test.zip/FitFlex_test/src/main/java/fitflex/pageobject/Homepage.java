package fitflex.pageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Homepage {
    WebDriver driver;
    public Homepage(WebDriver driver) {this.driver = driver; }

    public void activityclick() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            System.out.println(e.getMessage());
        }
        WebElement activity = driver.findElement(By.xpath("//*[contains(@src, 'images/home_page/u499.svg')]"));
        if (activity.isDisplayed()){
            System.out.println("2. Activity Validation Passed: ");
            System.out.println(" Activity button is is showing up on Home page");
        } else {
            System.out.println("2. Activity validation Failed");
        }
        wait.until(ExpectedConditions.visibilityOf(activity));
        activity.click();
        Thread.sleep(1000);

        WebElement homeiconclick = driver.findElement(By.cssSelector("#u637_img"));
        wait.until(ExpectedConditions.visibilityOf(homeiconclick));
        homeiconclick.click();
        Thread.sleep(1000);
    }



}
