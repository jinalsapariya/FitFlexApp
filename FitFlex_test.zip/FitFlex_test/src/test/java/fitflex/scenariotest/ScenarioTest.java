package fitflex.scenariotest;

import fitflex.pageobject.Homepage;
import fitflex.pageobject.Signuppage;
import fitflex.pageobject.Welcomepage;
import org.junit.After;
import org.junit.Before;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import sun.tools.tree.NewArrayExpression;

import javax.sound.midi.ShortMessage;

import static org.junit.Assert.assertEquals;

public class ScenarioTest {
    private WebDriver driver;
    private Welcomepage welcomepage;
    private Signuppage signup;
    private Homepage homepage;

    @BeforeClass
    public void setup() {
        System.setProperty("webdriver.chrome.driver", "/usr/local/bin/chromedriver");
        driver = new ChromeDriver();

    }

    @Test
    public void welcomePage_onClick_signup_button_goto_signup_page() throws InterruptedException {
        // setup
        driver.get("file:///Users/jinalsapariya/Documents/Axure/HTML/FitFlex%20App/welcome_page.html");
        welcomepage = new Welcomepage(driver);
        driver.manage().window().maximize();
        Thread.sleep(1000);
        welcomepage.goToSignup();
        Thread.sleep(1000);

        // test page changing from the welcome page to sign up page.
        assertEquals("file:///Users/jinalsapariya/Documents/Axure/HTML/FitFlex%20App/sign_up.html", driver.getCurrentUrl());
    }

    @Test
    public void authenticate_user_successful() throws InterruptedException {
        // setup
        driver.get("file:///Users/jinalsapariya/Documents/Axure/HTML/FitFlex%20App/sign_up.html");
        signup = new Signuppage(driver);
        driver.manage().window().maximize();
        signup.authenticateuser("Andrew123@gmail.com", "Andrew Jose", "Admin12345");

        // test page changing from sign up to home page.
        assertEquals("file:///Users/jinalsapariya/Documents/Axure/HTML/FitFlex%20App/home_page.html", driver.getCurrentUrl());
    }

    @Test
    public void authenticate_user_not_successful() throws InterruptedException {
        // setup
        driver.get("file:///Users/jinalsapariya/Documents/Axure/HTML/FitFlex%20App/sign_up.html");
        signup = new Signuppage(driver);
        driver.manage().window().maximize();
        signup.authenticateuser("Andrew123@gmail", "Andrew Jose", "Admin12345");

        // test page not changing from sign up to home page.
        assertEquals("file:///Users/jinalsapariya/Documents/Axure/HTML/FitFlex%20App/sign_up.html", driver.getCurrentUrl());
    }

    @AfterClass
    public void teardown(){
        driver.close();
    }


}
